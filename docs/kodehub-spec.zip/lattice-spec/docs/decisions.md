# Decision log

Record build-time decisions here: context, decision, consequence. Newest first.
